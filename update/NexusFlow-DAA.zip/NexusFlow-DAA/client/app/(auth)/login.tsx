import { useState } from "react";
import { View, Text, TextInput, Pressable, StyleSheet, Alert } from "react-native";
import { useAuth } from "@/context/AuthContext";

export default function Login() {
  const { signIn } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const onSubmit = async () => {
    setBusy(true);
    try {
      await signIn(email.trim(), password);
    } catch (e: any) {
      Alert.alert("Sign in failed", e.message ?? "Try again");
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={styles.c}>
      <Text style={styles.h}>NexusFlow</Text>
      <TextInput style={styles.i} placeholder="Email" autoCapitalize="none"
        keyboardType="email-address" value={email} onChangeText={setEmail} />
      <TextInput style={styles.i} placeholder="Password" secureTextEntry
        value={password} onChangeText={setPassword} />
      <Pressable style={[styles.b, busy && { opacity: 0.6 }]} disabled={busy} onPress={onSubmit}>
        <Text style={styles.bt}>{busy ? "Signing in…" : "Sign in"}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  c: { flex: 1, justifyContent: "center", padding: 24, gap: 12 },
  h: { fontSize: 32, fontWeight: "800", marginBottom: 24, textAlign: "center" },
  i: { borderWidth: 1, borderColor: "#d0d5dd", borderRadius: 10, padding: 14, fontSize: 16 },
  b: { backgroundColor: "#4f46e5", borderRadius: 10, padding: 16, alignItems: "center", marginTop: 8 },
  bt: { color: "#fff", fontSize: 16, fontWeight: "700" },
});
