import { useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  StyleSheet,
  TextInput,
  Pressable,
  Modal,
  ScrollView,
} from "react-native";
import { useRouter } from "expo-router";
import { useTeams } from "@/hooks/useTeams";
import TeamCard from "@/components/TeamCard";

export default function Dashboard() {
  const { teams, loading, error } = useTeams();
  const router = useRouter();

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" /></View>;
  if (error) return <View style={styles.center}><Text>Couldn't load teams.</Text></View>;

  return (
    <FlatList
      contentContainerStyle={styles.list}
      data={teams}
      keyExtractor={(t) => t._id}
      renderItem={({ item }) => (
        <TeamCard team={item} onPress={() => router.push(`/chat/${item._id}`)} />
      )}
      ListHeaderComponent={
        <View>
          <Text style={styles.h}>NexusFlow</Text>
          <Text style={styles.sub}>Intelligent Task Scheduling & Team Optimization</Text>
        </View>
      }
      ListEmptyComponent={<Text style={styles.empty}>No teams yet.</Text>}
    />
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  list: { padding: 16, gap: 12 },
  h: { fontSize: 26, fontWeight: "800", marginBottom: 2 },
  sub: { fontSize: 13, color: "#667085", marginBottom: 16 },
  empty: { textAlign: "center", color: "#667085", marginTop: 40 },
});
