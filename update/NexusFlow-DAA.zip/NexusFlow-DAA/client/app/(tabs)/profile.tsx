import { View, Text, Pressable, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useAuth } from "@/context/AuthContext";

export default function Profile() {
  const { user, signOut } = useAuth();

  return (
    <View style={styles.c}>
      <View style={styles.avatar}>
        <Ionicons name="person" size={48} color="#4f46e5" />
      </View>
      <Text style={styles.name}>{user?.name ?? "User"}</Text>
      <Text style={styles.email}>{user?.email ?? ""}</Text>

      <Pressable style={styles.signOut} onPress={signOut}>
        <Ionicons name="log-out-outline" size={20} color="#fff" />
        <Text style={styles.signOutText}>Sign out</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  c: { flex: 1, alignItems: "center", paddingTop: 64, gap: 8 },
  avatar: {
    width: 96, height: 96, borderRadius: 48, backgroundColor: "#eef2ff",
    justifyContent: "center", alignItems: "center", marginBottom: 12,
  },
  name: { fontSize: 22, fontWeight: "800" },
  email: { fontSize: 15, color: "#667085" },
  signOut: {
    flexDirection: "row", gap: 8, backgroundColor: "#ef4444", paddingHorizontal: 24,
    paddingVertical: 14, borderRadius: 10, marginTop: 32, alignItems: "center",
  },
  signOutText: { color: "#fff", fontWeight: "700", fontSize: 16 },
});
