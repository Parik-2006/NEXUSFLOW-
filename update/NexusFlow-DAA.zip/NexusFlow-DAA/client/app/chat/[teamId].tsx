import { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  Pressable,
  StyleSheet,
  Modal,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { useLocalSearchParams } from "expo-router";
import { GiftedChat, IMessage } from "react-native-gifted-chat";
import { getSocket } from "@/services/socket";
import { useAuth } from "@/context/AuthContext";
import { useTeamTasks, Task } from "@/hooks/useTeamTasks";
import TaskCard from "@/components/TaskCard";

export default function TeamChat() {
  const { teamId } = useLocalSearchParams<{ teamId: string }>();
  const { user, token } = useAuth();
  const [messages, setMessages] = useState<IMessage[]>([]);
  const [activeTab, setActiveTab] = useState<"chat" | "tasks" | "plan">("chat");

  // DAA hooks
  const {
    tasks,
    loading: tasksLoading,
    setStatus,
    searchTasks,
    clearSearch,
    fetchGreedyPlan,
    fetchKnapsackPlan,
    fetchExecutionOrder,
    triggerOptimalAssignment,
    sprintPlan,
    executionOrder,
  } = useTeamTasks(teamId);

  const [searchQuery, setSearchQuery] = useState("");
  const [sprintModalVisible, setSprintModalVisible] = useState(false);
  const [planType, setPlanType] = useState<"greedy" | "knapsack">("knapsack");
  const [planLoading, setPlanLoading] = useState(false);
  const [assignLoading, setAssignLoading] = useState(false);

  // ── Chat socket wiring (unchanged) ────────────────────────────────────────
  useEffect(() => {
    const socket = getSocket(token);
    socket.emit("room:join", { teamId });

    const onMessage = (m: any) => {
      setMessages((prev) =>
        GiftedChat.append(prev, [{
          _id: m._id,
          text: m.text,
          createdAt: new Date(m.createdAt),
          user: { _id: m.userId, name: m.name },
        }])
      );
    };

    const onStream = (chunk: any) => {
      setMessages((prev) =>
        GiftedChat.append(prev, [{
          _id: chunk.id,
          text: chunk.text,
          createdAt: new Date(),
          user: { _id: "ai", name: "NexusFlow AI" },
        }])
      );
    };

    socket.on("chat:message", onMessage);
    socket.on("chat:stream", onStream);
    return () => {
      socket.emit("room:leave", { teamId });
      socket.off("chat:message", onMessage);
      socket.off("chat:stream", onStream);
    };
  }, [teamId, token]);

  const onSend = useCallback((outgoing: IMessage[] = []) => {
    const socket = getSocket(token);
    setMessages((prev) => GiftedChat.append(prev, outgoing));
    socket.emit("chat:message", { teamId, text: outgoing[0]?.text });
  }, [teamId, token]);

  // ── Boyer-Moore search handler ────────────────────────────────────────────
  const handleSearch = useCallback(async (q: string) => {
    setSearchQuery(q);
    if (!q.trim()) { clearSearch(); return; }
    await searchTasks(q);
  }, [searchTasks, clearSearch]);

  // ── Sprint plan handler ───────────────────────────────────────────────────
  const handlePlan = useCallback(async () => {
    setPlanLoading(true);
    if (planType === "greedy") await fetchGreedyPlan(80);
    else await fetchKnapsackPlan(80);
    setPlanLoading(false);
    setSprintModalVisible(true);
  }, [planType, fetchGreedyPlan, fetchKnapsackPlan]);

  // ── B&B assignment handler ────────────────────────────────────────────────
  const handleAssign = useCallback(async () => {
    setAssignLoading(true);
    await triggerOptimalAssignment();
    setAssignLoading(false);
  }, [triggerOptimalAssignment]);

  const plannedTasks = sprintPlan?.scheduled ?? sprintPlan?.selected ?? [];

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <View style={styles.container}>
      {/* Tab bar */}
      <View style={styles.tabs}>
        {(["chat", "tasks", "plan"] as const).map((tab) => (
          <Pressable key={tab} style={[styles.tab, activeTab === tab && styles.activeTab]} onPress={() => setActiveTab(tab)}>
            <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>
              {tab === "chat" ? "💬 Chat" : tab === "tasks" ? "📋 Tasks" : "📊 Plan"}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* Chat tab */}
      {activeTab === "chat" && (
        <GiftedChat
          messages={messages}
          onSend={onSend}
          user={{ _id: user?.id ?? "me", name: user?.name }}
        />
      )}

      {/* Tasks tab — Boyer-Moore search + Merge Sort ranked list */}
      {activeTab === "tasks" && (
        <View style={styles.taskPane}>
          {/* Boyer-Moore search bar */}
          <View style={styles.searchRow}>
            <TextInput
              style={styles.searchInput}
              placeholder="🔍 Search tasks (Boyer-Moore)…"
              value={searchQuery}
              onChangeText={handleSearch}
              clearButtonMode="while-editing"
            />
          </View>

          <View style={styles.actionRow}>
            <Pressable style={styles.actionBtn} onPress={handleAssign} disabled={assignLoading}>
              <Text style={styles.actionBtnText}>
                {assignLoading ? "Assigning…" : "⚡ B&B Assign"}
              </Text>
            </Pressable>
            <Pressable style={[styles.actionBtn, styles.planBtn]} onPress={handlePlan} disabled={planLoading}>
              <Text style={styles.actionBtnText}>
                {planLoading ? "Planning…" : planType === "knapsack" ? "🎒 Knapsack Plan" : "📈 Greedy Plan"}
              </Text>
            </Pressable>
            <Pressable
              style={styles.toggleBtn}
              onPress={() => setPlanType(t => t === "greedy" ? "knapsack" : "greedy")}
            >
              <Text style={styles.toggleBtnText}>⇄</Text>
            </Pressable>
          </View>

          {searchQuery.length > 0 && (
            <Text style={styles.searchHint}>Boyer-Moore: {tasks.length} match{tasks.length !== 1 ? "es" : ""} for "{searchQuery}"</Text>
          )}

          {tasksLoading ? (
            <ActivityIndicator style={{ marginTop: 40 }} />
          ) : (
            <FlatList
              data={tasks}
              keyExtractor={(t) => t._id}
              contentContainerStyle={{ gap: 10, padding: 16 }}
              renderItem={({ item }) => (
                <TaskCard
                  task={item}
                  onCycle={(next) => setStatus(item._id, next)}
                />
              )}
              ListEmptyComponent={
                <Text style={styles.empty}>
                  {searchQuery ? "No tasks match your search." : "No tasks yet. Use @ai in chat to generate some."}
                </Text>
              }
            />
          )}
        </View>
      )}

      {/* Plan tab — Topological Sort execution order */}
      {activeTab === "plan" && (
        <ScrollView contentContainerStyle={styles.planPane}>
          <Text style={styles.planTitle}>Execution Order</Text>
          <Text style={styles.planSub}>Topological Sort (Kahn's Algorithm)</Text>
          <Pressable style={styles.actionBtn} onPress={fetchExecutionOrder}>
            <Text style={styles.actionBtnText}>🔄 Compute Order</Text>
          </Pressable>

          {executionOrder?.hasCycle && (
            <View style={styles.cycleWarning}>
              <Text style={styles.cycleText}>⚠ Circular dependency detected. Check tasks: {executionOrder.cycleNodes?.join(", ")}</Text>
            </View>
          )}

          {executionOrder?.levels.map((wave, idx) => (
            <View key={idx} style={styles.waveBlock}>
              <Text style={styles.waveLabel}>Sprint Wave {idx + 1} ({wave.length} tasks)</Text>
              {wave.map((task) => (
                <View key={task._id} style={styles.waveTask}>
                  <View style={[styles.dot, { backgroundColor: task.priority === "high" ? "#ef4444" : task.priority === "medium" ? "#f59e0b" : "#6b7280" }]} />
                  <Text style={styles.waveTaskTitle} numberOfLines={1}>{task.title}</Text>
                  <Text style={styles.waveTaskMeta}>{task.estimatedHours}h</Text>
                </View>
              ))}
            </View>
          ))}

          {!executionOrder && (
            <Text style={styles.empty}>Tap "Compute Order" to run Topological Sort.</Text>
          )}
        </ScrollView>
      )}

      {/* Sprint Plan Modal (Greedy / Knapsack) */}
      <Modal visible={sprintModalVisible} animationType="slide" presentationStyle="pageSheet">
        <View style={styles.modal}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Sprint Plan — {sprintPlan?.algorithm}</Text>
            <Pressable onPress={() => setSprintModalVisible(false)}>
              <Text style={styles.closeBtn}>✕</Text>
            </Pressable>
          </View>

          {sprintPlan && (
            <View style={styles.statsRow}>
              <Stat label="Tasks" value={String(plannedTasks.length)} />
              <Stat label="Hours" value={`${sprintPlan.usedHours ?? sprintPlan.totalHours ?? 0}h`} />
              <Stat label="Utilisation" value={`${sprintPlan.utilisation}%`} />
            </View>
          )}

          <ScrollView contentContainerStyle={{ gap: 10, padding: 16 }}>
            {plannedTasks.map((task) => (
              <TaskCard key={task._id} task={task} onCycle={() => {}} />
            ))}
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f9fafb" },
  tabs: { flexDirection: "row", backgroundColor: "#fff", borderBottomWidth: 1, borderBottomColor: "#e5e7eb" },
  tab: { flex: 1, paddingVertical: 12, alignItems: "center" },
  activeTab: { borderBottomWidth: 2, borderBottomColor: "#6366f1" },
  tabText: { fontSize: 13, color: "#6b7280", fontWeight: "600" },
  activeTabText: { color: "#6366f1" },
  taskPane: { flex: 1 },
  searchRow: { padding: 12, paddingBottom: 4 },
  searchInput: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 10,
    fontSize: 14,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  actionRow: { flexDirection: "row", gap: 8, paddingHorizontal: 12, paddingBottom: 8 },
  actionBtn: {
    flex: 1,
    backgroundColor: "#6366f1",
    borderRadius: 8,
    paddingVertical: 8,
    alignItems: "center",
  },
  planBtn: { backgroundColor: "#059669" },
  actionBtnText: { color: "#fff", fontWeight: "700", fontSize: 12 },
  toggleBtn: { backgroundColor: "#e5e7eb", borderRadius: 8, paddingHorizontal: 10, justifyContent: "center" },
  toggleBtnText: { fontSize: 16, color: "#374151" },
  searchHint: { fontSize: 11, color: "#6366f1", paddingHorizontal: 16, paddingBottom: 4 },
  empty: { textAlign: "center", color: "#9ca3af", marginTop: 40, paddingHorizontal: 32 },
  planPane: { padding: 16, gap: 12 },
  planTitle: { fontSize: 20, fontWeight: "800", color: "#111827" },
  planSub: { fontSize: 12, color: "#6b7280", marginBottom: 8 },
  waveBlock: { backgroundColor: "#fff", borderRadius: 10, padding: 12, gap: 8 },
  waveLabel: { fontSize: 13, fontWeight: "700", color: "#6366f1", marginBottom: 4 },
  waveTask: { flexDirection: "row", alignItems: "center", gap: 8 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  waveTaskTitle: { flex: 1, fontSize: 13, color: "#111827" },
  waveTaskMeta: { fontSize: 11, color: "#9ca3af" },
  cycleWarning: { backgroundColor: "#fef2f2", borderRadius: 8, padding: 12, borderWidth: 1, borderColor: "#fca5a5" },
  cycleText: { fontSize: 13, color: "#dc2626" },
  modal: { flex: 1, backgroundColor: "#f9fafb" },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 16, borderBottomWidth: 1, borderBottomColor: "#e5e7eb", backgroundColor: "#fff" },
  modalTitle: { fontSize: 16, fontWeight: "700", color: "#111827", flex: 1 },
  closeBtn: { fontSize: 18, color: "#6b7280", paddingLeft: 16 },
  statsRow: { flexDirection: "row", backgroundColor: "#fff", padding: 16, gap: 16, borderBottomWidth: 1, borderBottomColor: "#e5e7eb" },
  stat: { flex: 1, alignItems: "center" },
  statValue: { fontSize: 20, fontWeight: "800", color: "#6366f1" },
  statLabel: { fontSize: 11, color: "#6b7280", marginTop: 2 },
});
