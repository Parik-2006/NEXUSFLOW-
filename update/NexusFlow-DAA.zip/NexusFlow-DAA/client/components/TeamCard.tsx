import { View, Text, Pressable, StyleSheet } from "react-native";
import ProgressBar from "./ProgressBar";
import type { Team } from "@/hooks/useTeams";

export default function TeamCard({ team, onPress }: { team: Team; onPress: () => void }) {
  const ratio = team.taskCount ? team.doneCount / team.taskCount : 0;
  return (
    <Pressable style={styles.card} onPress={onPress}>
      <Text style={styles.name}>{team.name}</Text>
      <Text style={styles.sub}>{team.doneCount}/{team.taskCount} tasks done</Text>
      <ProgressBar value={ratio} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff", borderRadius: 14, padding: 16, gap: 8,
    shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 8, shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  name: { fontSize: 18, fontWeight: "700" },
  sub: { fontSize: 13, color: "#667085" },
});
