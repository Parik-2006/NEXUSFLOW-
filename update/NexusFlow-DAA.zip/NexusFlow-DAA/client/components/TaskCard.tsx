import { View, Text, Pressable, StyleSheet } from "react-native";
import type { Task } from "@/hooks/useTeamTasks";

const NEXT: Record<Task["status"], Task["status"]> = {
  todo: "in_progress",
  in_progress: "done",
  done: "todo",
};

const LABEL: Record<Task["status"], string> = {
  todo: "To do",
  in_progress: "In progress",
  done: "Done",
};

const STATUS_COLOR: Record<Task["status"], string> = {
  todo: "#9ca3af",
  in_progress: "#f59e0b",
  done: "#10b981",
};

// DAA: priority visual indicators (drives Greedy + Knapsack value function)
const PRIORITY_COLOR: Record<NonNullable<Task["priority"]>, string> = {
  high: "#ef4444",
  medium: "#f59e0b",
  low: "#6b7280",
};

const PRIORITY_LABEL: Record<NonNullable<Task["priority"]>, string> = {
  high: "HIGH",
  medium: "MED",
  low: "LOW",
};

export default function TaskCard({
  task,
  onCycle,
}: {
  task: Task;
  onCycle: (next: Task["status"]) => void;
}) {
  const priority = task.priority ?? "medium";
  const hasDeps = (task.dependencies?.length ?? 0) > 0;
  const isAssigned = !!task.assignedTo;

  return (
    <Pressable style={styles.card} onPress={() => onCycle(NEXT[task.status])}>
      {/* Top row: status dot + title + priority badge */}
      <View style={styles.topRow}>
        <View style={[styles.dot, { backgroundColor: STATUS_COLOR[task.status] }]} />
        <Text style={[styles.title, task.status === "done" && styles.done]} numberOfLines={2}>
          {task.title}
        </Text>
        <View style={[styles.priorityBadge, { backgroundColor: PRIORITY_COLOR[priority] + "22", borderColor: PRIORITY_COLOR[priority] }]}>
          <Text style={[styles.priorityLabel, { color: PRIORITY_COLOR[priority] }]}>
            {PRIORITY_LABEL[priority]}
          </Text>
        </View>
      </View>

      {/* Bottom row: status badge + effort + dependency indicator + assignee */}
      <View style={styles.bottomRow}>
        <Text style={[styles.statusBadge, { color: STATUS_COLOR[task.status] }]}>
          {LABEL[task.status]}
        </Text>

        {/* DAA: Knapsack weight display */}
        {task.estimatedHours != null && (
          <View style={styles.metaChip}>
            <Text style={styles.metaText}>⏱ {task.estimatedHours}h</Text>
          </View>
        )}

        {/* DAA: Dependency indicator — shown when task has prerequisite edges */}
        {hasDeps && (
          <View style={[styles.metaChip, styles.depChip]}>
            <Text style={styles.metaText}>🔗 {task.dependencies!.length} dep</Text>
          </View>
        )}

        {/* DAA: Branch-and-Bound assignment indicator */}
        {isAssigned && (
          <View style={[styles.metaChip, styles.assignChip]}>
            <Text style={styles.metaText}>👤</Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 14,
    gap: 8,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  topRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  dot: { width: 10, height: 10, borderRadius: 5, marginTop: 4, flexShrink: 0 },
  title: { flex: 1, fontSize: 15, fontWeight: "600", color: "#111827" },
  done: { textDecorationLine: "line-through", color: "#9ca3af" },
  priorityBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    borderWidth: 1,
    flexShrink: 0,
  },
  priorityLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 0.5 },
  bottomRow: { flexDirection: "row", alignItems: "center", gap: 6, flexWrap: "wrap" },
  statusBadge: { fontSize: 12, fontWeight: "700" },
  metaChip: {
    backgroundColor: "#f3f4f6",
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  depChip: { backgroundColor: "#ede9fe" },
  assignChip: { backgroundColor: "#dcfce7" },
  metaText: { fontSize: 11, color: "#374151", fontWeight: "600" },
});
