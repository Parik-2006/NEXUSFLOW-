import { useCallback, useEffect, useRef, useState } from "react";
import { getSocket } from "@/services/socket";
import { useAuth } from "@/context/AuthContext";

const API = process.env.EXPO_PUBLIC_API_URL ?? "http://localhost:4000";

export type Task = {
  _id: string;
  teamId: string;
  title: string;
  description?: string;
  status: "todo" | "in_progress" | "done";
  priority: "low" | "medium" | "high";
  estimatedHours: number;
  storyPoints?: number;
  dueDate?: string | null;
  dependencies?: string[];
  tags?: string[];
  assignedTo?: string | null;
  updatedAt?: string;
  createdAt?: string;
};

export type SprintPlan = {
  algorithm: string;
  scheduled?: Task[];
  selected?: Task[];
  usedHours?: number;
  totalHours?: number;
  utilisation: number;
};

export type ExecutionOrder = {
  ordered: Task[];
  levels: Task[][];
  hasCycle: boolean;
  cycleNodes?: string[];
};

export function useTeamTasks(teamId: string) {
  const { token } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [sprintPlan, setSprintPlan] = useState<SprintPlan | null>(null);
  const [executionOrder, setExecutionOrder] = useState<ExecutionOrder | null>(null);
  const [searchResults, setSearchResults] = useState<Task[] | null>(null);
  const lastSync = useRef<string | null>(null);

  // REST hydrate (snapshot) — server returns Merge Sorted order.
  const hydrate = useCallback(async () => {
    const res = await fetch(`${API}/api/teams/${teamId}/tasks`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      const data: Task[] = await res.json();
      setTasks(data); // already Merge Sorted by server
      lastSync.current = new Date().toISOString();
    }
    setLoading(false);
  }, [teamId, token]);

  useEffect(() => { hydrate(); }, [hydrate]);

  // Subscribe to live deltas + reconnection replay.
  useEffect(() => {
    const socket = getSocket(token);
    socket.emit("room:join", { teamId });

    const onCreated = (task: Task) =>
      setTasks((prev) => (prev.some((t) => t._id === task._id) ? prev : [task, ...prev]));

    const onUpdated = (task: Task) =>
      setTasks((prev) => prev.map((t) => (t._id === task._id ? { ...t, ...task } : t)));

    // DAA: server emits re-ranked list after every create/AI generate
    const onReranked = (payload: { teamId: string; tasks: Task[] }) => {
      if (payload.teamId === teamId) setTasks(payload.tasks);
    };

    socket.on("task:created", onCreated);
    socket.on("task:updated", onUpdated);
    socket.on("task:reranked", onReranked);
    socket.on("reconnect", hydrate);

    return () => {
      socket.emit("room:leave", { teamId });
      socket.off("task:created", onCreated);
      socket.off("task:updated", onUpdated);
      socket.off("task:reranked", onReranked);
      socket.off("reconnect", hydrate);
    };
  }, [teamId, token, hydrate]);

  // Optimistic status change with rollback.
  const setStatus = useCallback((taskId: string, status: Task["status"]) => {
    const socket = getSocket(token);
    let prevStatus: Task["status"] | undefined;

    setTasks((prev) =>
      prev.map((t) => {
        if (t._id === taskId) { prevStatus = t.status; return { ...t, status }; }
        return t;
      })
    );

    socket.emit(
      "task:update",
      { teamId, taskId, status, prevStatus },
      (ack: { ok: boolean }) => {
        if (!ack?.ok && prevStatus) {
          setTasks((prev) =>
            prev.map((t) => (t._id === taskId ? { ...t, status: prevStatus! } : t))
          );
        }
      }
    );
  }, [teamId, token]);

  // ── DAA: Greedy Sprint Plan ─────────────────────────────────────────────────
  const fetchGreedyPlan = useCallback(async (capacityHours: number) => {
    const res = await fetch(`${API}/api/teams/${teamId}/sprint/greedy`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ capacityHours }),
    });
    if (res.ok) {
      const data: SprintPlan = await res.json();
      setSprintPlan(data);
      return data;
    }
    return null;
  }, [teamId, token]);

  // ── DAA: Knapsack Sprint Plan ───────────────────────────────────────────────
  const fetchKnapsackPlan = useCallback(async (capacityHours: number) => {
    const res = await fetch(`${API}/api/teams/${teamId}/sprint/knapsack`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ capacityHours }),
    });
    if (res.ok) {
      const data: SprintPlan = await res.json();
      setSprintPlan(data);
      return data;
    }
    return null;
  }, [teamId, token]);

  // ── DAA: Topological Execution Order ───────────────────────────────────────
  const fetchExecutionOrder = useCallback(async () => {
    const res = await fetch(`${API}/api/teams/${teamId}/tasks/execution-order`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      const data: ExecutionOrder = await res.json();
      setExecutionOrder(data);
      return data;
    }
    return null;
  }, [teamId, token]);

  // ── DAA: Boyer-Moore Search ─────────────────────────────────────────────────
  const searchTasks = useCallback(async (query: string) => {
    if (!query.trim()) { setSearchResults(null); return tasks; }
    const res = await fetch(
      `${API}/api/teams/${teamId}/tasks/search?q=${encodeURIComponent(query)}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (res.ok) {
      const data = await res.json();
      setSearchResults(data.results);
      return data.results as Task[];
    }
    return tasks;
  }, [teamId, token, tasks]);

  const clearSearch = useCallback(() => setSearchResults(null), []);

  // ── DAA: B&B Optimal Assignment ────────────────────────────────────────────
  const triggerOptimalAssignment = useCallback(async (taskIds?: string[]) => {
    const res = await fetch(`${API}/api/teams/${teamId}/assign`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ taskIds }),
    });
    if (res.ok) {
      await hydrate(); // refresh with updated assignments
      return await res.json();
    }
    return null;
  }, [teamId, token, hydrate]);

  // ── DAA: Add dependency edge ────────────────────────────────────────────────
  const addDependency = useCallback((taskId: string, dependsOnTaskId: string) => {
    return new Promise<{ ok: boolean; error?: string }>((resolve) => {
      const socket = getSocket(token);
      socket.emit("task:dep:add", { teamId, taskId, dependsOnTaskId }, (ack: any) => {
        if (ack?.ok) hydrate(); // refresh task list to show updated deps
        resolve(ack ?? { ok: false });
      });
    });
  }, [teamId, token, hydrate]);

  // Visible task list: search results override full list
  const visibleTasks = searchResults ?? tasks;

  return {
    tasks: visibleTasks,
    allTasks: tasks,
    loading,
    setStatus,
    refetch: hydrate,
    // DAA
    sprintPlan,
    executionOrder,
    searchResults,
    fetchGreedyPlan,
    fetchKnapsackPlan,
    fetchExecutionOrder,
    searchTasks,
    clearSearch,
    triggerOptimalAssignment,
    addDependency,
  };
}
