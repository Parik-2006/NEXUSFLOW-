# NexusFlow DAA
## Intelligent Task Scheduling and Team Optimization System

> **4th Semester DAA Project** — Design and Analysis of Algorithms

---

## Quick Start

```bash
# Server
cd server
npm install
cp .env.example .env       # set MONGO_URI and JWT_SECRET
npm run dev                # starts on :4000

# Run all 41 algorithm unit tests
npm test

# Client
cd client
npm install
cp .env.example .env       # set EXPO_PUBLIC_API_URL=http://localhost:4000
npx expo start
```

---

## Algorithms Integrated

| # | Algorithm | Problem Solved | Complexity | File |
|---|---|---|---|---|
| 1 | Merge Sort | Rank tasks by priority/deadline | O(n log n) | `server/algorithms/index.js` |
| 2 | Topological Sort | Task execution ordering | O(V+E) | `server/algorithms/index.js` |
| 3 | DFS | Downstream impact analysis | O(V+E) | `server/algorithms/index.js` |
| 4 | BFS | Sprint wave planning | O(V+E) | `server/algorithms/index.js` |
| 5 | Greedy | Real-time sprint prioritization | O(n log n) | `server/algorithms/index.js` |
| 6 | 0/1 Knapsack | Optimal sprint planning (DP) | O(n×W) | `server/algorithms/index.js` |
| 7 | Branch & Bound | Optimal task-member assignment | O(M^N)/O(M×N) | `server/algorithms/index.js` |
| 8 | Boyer-Moore | Fast task keyword search | O(n/m) avg | `server/algorithms/index.js` |

---

## API Endpoints

### Existing (backward-compatible)
```
GET  /api/teams                               → list teams
GET  /api/teams/:id/tasks                     → sorted task list (Merge Sort)
POST /api/login                               → authenticate
POST /api/register                            → create user
GET  /api/me                                  → current user profile
```

### New DAA Endpoints
```
GET  /api/teams/:id/tasks/execution-order     → Topological Sort
GET  /api/teams/:id/tasks/wave-plan           → BFS wave plan
GET  /api/teams/:id/tasks/:taskId/blocked     → DFS blocked tasks
GET  /api/teams/:id/tasks/search?q=<query>    → Boyer-Moore search
POST /api/teams/:id/sprint/greedy             → Greedy sprint plan
POST /api/teams/:id/sprint/knapsack           → Knapsack optimal plan
POST /api/teams/:id/assign                    → B&B optimal assignment
POST /api/teams                               → create team
PUT  /api/teams/:id/members/:uid/profile      → upsert member skill profile
```

### Socket Events
```
task:create    → creates task + validates DAG (Topo Sort)
task:dep:add   → adds dependency edge + cycle guard (Topo Sort)
task:update    → updates status
task:reorder   → requests Merge Sort re-rank
task:reranked  → server broadcasts sorted task list
```

---

## Schema Changes

### Task (new fields — all optional, backward compatible)
```
priority        : "low" | "medium" | "high"   (default "medium")
estimatedHours  : Number                       (default 1)
storyPoints     : Number                       (default 1)
dueDate         : Date | null                  (default null)
dependencies    : [ObjectId]                   (DAG edges)
tags            : [String]
assignedTo      : String | null
description     : String
```

### Team (new fields — all optional)
```
memberProfiles     : [{ userId, name, skills[], seniority,
                        weeklyCapacityHours, completionRate }]
sprintCapacityHours : Number (default 80)
```

---

## Modified Files

| File | Change | Reason |
|---|---|---|
| `server/algorithms/index.js` | **NEW** | All 8 DAA implementations |
| `server/models/Task.js` | Modified | +8 DAA-relevant fields |
| `server/models/Team.js` | Modified | +memberProfiles, +sprintCapacity |
| `server/models/User.js` | New | Was missing; added with bcrypt |
| `server/index.js` | Modified | Mounts teamRouter, socket handlers |
| `server/routes/teams.js` | Modified | +7 new DAA REST endpoints |
| `server/socket/taskHandlers.js` | Modified | Topo Sort cycle guard on dep:add |
| `server/socket/aiOrchestrator.js` | Modified | Greedy analysis after AI task gen |
| `client/hooks/useTeamTasks.ts` | Modified | +6 DAA async methods |
| `client/components/TaskCard.tsx` | Modified | Priority badge, effort, dep count |
| `client/app/chat/[teamId].tsx` | Modified | Search bar, sprint panel, topo view |
| `client/app/(tabs)/dashboard.tsx` | Modified | Updated subtitle |
| `server/algorithms/algorithms.test.js` | **NEW** | 41 unit tests (all pass) |
| `DAA_REPORT.md` | **NEW** | Full project report |
| `DAA_ARCHITECTURE.html` | **NEW** | Interactive architecture diagram |

---

## Test Results

```
📊 Merge Sort         6/6 ✅
🔀 Topological Sort   5/5 ✅
🌊 DFS               4/4 ✅
🌐 BFS               3/3 ✅
⚡ Greedy            5/5 ✅
🎒 0/1 Knapsack      5/5 ✅
🌲 Branch & Bound    5/5 ✅
🔍 Boyer-Moore       8/8 ✅

Total: 41/41 passed
```
