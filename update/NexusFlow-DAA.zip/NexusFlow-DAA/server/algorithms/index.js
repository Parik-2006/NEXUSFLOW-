/**
 * NexusFlow — DAA Algorithm Suite
 * ================================
 * Implements all required Design and Analysis of Algorithms for the
 * Intelligent Task Scheduling and Team Optimization System.
 *
 * Each algorithm solves a concrete, production-relevant problem.
 */

// ─────────────────────────────────────────────────────────────────────────────
// 1. MERGE SORT — Task list sorting by composite priority key
//    Real-world use: The client receives tasks in insertion order from MongoDB.
//    We sort them by (priority DESC, dueDate ASC, createdAt ASC) so the most
//    urgent work surfaces at the top of every team board.
//
//    Time  : O(n log n)   guaranteed — better than quick-sort's O(n²) worst case
//    Space : O(n)         auxiliary array for merge step
// ─────────────────────────────────────────────────────────────────────────────
export function mergeSortTasks(tasks) {
  if (tasks.length <= 1) return tasks;

  const mid = Math.floor(tasks.length / 2);
  const left = mergeSortTasks(tasks.slice(0, mid));
  const right = mergeSortTasks(tasks.slice(mid));
  return mergeTasks(left, right);
}

function mergeTasks(left, right) {
  const result = [];
  let i = 0, j = 0;

  while (i < left.length && j < right.length) {
    // Primary key: priority (HIGH=3 > MEDIUM=2 > LOW=1)
    const lp = PRIORITY_WEIGHT[left[i].priority] ?? 1;
    const rp = PRIORITY_WEIGHT[right[j].priority] ?? 1;

    if (lp !== rp) {
      result.push(lp > rp ? left[i++] : right[j++]);
    } else {
      // Secondary key: due date ascending (closer deadline first)
      const ld = left[i].dueDate ? new Date(left[i].dueDate).getTime() : Infinity;
      const rd = right[j].dueDate ? new Date(right[j].dueDate).getTime() : Infinity;

      if (ld !== rd) {
        result.push(ld < rd ? left[i++] : right[j++]);
      } else {
        // Tertiary key: creation timestamp ascending (FIFO)
        const lc = new Date(left[i].createdAt).getTime();
        const rc = new Date(right[j].createdAt).getTime();
        result.push(lc <= rc ? left[i++] : right[j++]);
      }
    }
  }

  return result.concat(left.slice(i)).concat(right.slice(j));
}

const PRIORITY_WEIGHT = { high: 3, medium: 2, low: 1 };

// ─────────────────────────────────────────────────────────────────────────────
// 2. TOPOLOGICAL SORT — Task dependency execution ordering
//    Real-world use: Tasks can have prerequisites (e.g., "Deploy server" must
//    wait for "Write server code"). Topological Sort gives a valid sequential
//    execution plan for the entire DAG, and detects circular dependencies.
//
//    Uses Kahn's BFS-based algorithm (preferred over DFS for cycle detection).
//    Time  : O(V + E)   V = tasks, E = dependency edges
//    Space : O(V + E)
// ─────────────────────────────────────────────────────────────────────────────
export function topologicalSort(tasks) {
  const taskMap = new Map(tasks.map((t) => [String(t._id), t]));

  // Build adjacency list + in-degree map
  const adjList = new Map();   // taskId → [dependentTaskIds]
  const inDegree = new Map();  // taskId → count of unresolved prerequisites

  for (const t of tasks) {
    const id = String(t._id);
    if (!adjList.has(id)) adjList.set(id, []);
    if (!inDegree.has(id)) inDegree.set(id, 0);

    for (const dep of (t.dependencies ?? [])) {
      const depId = String(dep);
      if (!adjList.has(depId)) adjList.set(depId, []);
      adjList.get(depId).push(id);          // dep → this task
      inDegree.set(id, (inDegree.get(id) ?? 0) + 1);
    }
  }

  // Kahn's algorithm: start with tasks that have no prerequisites
  const queue = [];
  for (const [id, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(id);
  }

  const ordered = [];
  const levels = [];   // BFS levels = dependency depth layers

  while (queue.length > 0) {
    const levelSize = queue.length;
    const currentLevel = [];

    for (let i = 0; i < levelSize; i++) {
      const id = queue.shift();
      const task = taskMap.get(id);
      if (task) {
        ordered.push(task);
        currentLevel.push(task);
      }

      for (const neighbour of (adjList.get(id) ?? [])) {
        inDegree.set(neighbour, inDegree.get(neighbour) - 1);
        if (inDegree.get(neighbour) === 0) queue.push(neighbour);
      }
    }

    if (currentLevel.length > 0) levels.push(currentLevel);
  }

  const hasCycle = ordered.length < tasks.length;
  const cycleNodes = hasCycle
    ? tasks.filter((t) => !ordered.includes(t)).map((t) => String(t._id))
    : [];

  return { ordered, levels, hasCycle, cycleNodes };
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. DFS — Dependency chain traversal (find all blocked tasks)
//    Real-world use: When a task is blocked/deleted, DFS traverses the full
//    downstream dependency tree to surface every task that will be impacted.
//    Also used to detect reachability between two tasks in the DAG.
//
//    Time  : O(V + E)
//    Space : O(V)  — call stack depth bounded by longest dependency chain
// ─────────────────────────────────────────────────────────────────────────────
export function dfsBlockedTasks(tasks, startTaskId) {
  // Build forward adjacency: dep → tasks that depend on it
  const adjList = new Map();
  for (const t of tasks) {
    const id = String(t._id);
    if (!adjList.has(id)) adjList.set(id, []);

    for (const dep of (t.dependencies ?? [])) {
      const depId = String(dep);
      if (!adjList.has(depId)) adjList.set(depId, []);
      adjList.get(depId).push(id);
    }
  }

  const visited = new Set();
  const stack = [String(startTaskId)];

  while (stack.length > 0) {
    const current = stack.pop();
    if (visited.has(current)) continue;
    visited.add(current);

    for (const neighbour of (adjList.get(current) ?? [])) {
      if (!visited.has(neighbour)) stack.push(neighbour);
    }
  }

  visited.delete(String(startTaskId)); // exclude the start node itself
  const taskMap = new Map(tasks.map((t) => [String(t._id), t]));
  return [...visited].map((id) => taskMap.get(id)).filter(Boolean);
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. BFS — Dependency level exploration
//    Real-world use: Sprint planning needs to know which tasks are immediately
//    unblocked (layer 0), which become available after one sprint (layer 1),
//    etc. BFS produces exact execution waves for sprint calendaring.
//
//    Time  : O(V + E)
//    Space : O(V)
// ─────────────────────────────────────────────────────────────────────────────
export function bfsDependencyLevels(tasks) {
  const taskMap = new Map(tasks.map((t) => [String(t._id), t]));
  const inDegree = new Map();
  const adjList = new Map();

  for (const t of tasks) {
    const id = String(t._id);
    if (!inDegree.has(id)) inDegree.set(id, 0);
    if (!adjList.has(id)) adjList.set(id, []);

    for (const dep of (t.dependencies ?? [])) {
      const depId = String(dep);
      if (!adjList.has(depId)) adjList.set(depId, []);
      adjList.get(depId).push(id);
      inDegree.set(id, (inDegree.get(id) ?? 0) + 1);
    }
  }

  let queue = [];
  for (const [id, deg] of inDegree.entries()) {
    if (deg === 0) queue.push(id);
  }

  const wavePlan = [];  // array of arrays — each index is a sprint wave

  while (queue.length > 0) {
    const wave = queue.map((id) => taskMap.get(id)).filter(Boolean);
    wavePlan.push(wave);

    const nextQueue = [];
    for (const id of queue) {
      for (const neighbour of (adjList.get(id) ?? [])) {
        inDegree.set(neighbour, inDegree.get(neighbour) - 1);
        if (inDegree.get(neighbour) === 0) nextQueue.push(neighbour);
      }
    }
    queue = nextQueue;
  }

  return wavePlan;  // wavePlan[0] = sprint 0 tasks, wavePlan[1] = sprint 1, …
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. GREEDY SCHEDULING — Task prioritization within sprint capacity
//    Real-world use: A sprint has limited team hours. Greedy selects tasks
//    ordered by (priority DESC, effort ASC) ensuring maximum business value
//    is delivered within the time-box, without needing global optimisation.
//
//    This is the Activity Selection variant of Greedy.
//    Time  : O(n log n)  — sort step dominates
//    Space : O(n)
// ─────────────────────────────────────────────────────────────────────────────
export function greedySchedule(tasks, sprintCapacityHours) {
  // Only schedule tasks not yet started or explicitly marked for this sprint
  const eligible = tasks.filter((t) => t.status !== "done");

  // Sort: primary = priority weight DESC, secondary = estimated hours ASC (prefer quick wins)
  const sorted = [...eligible].sort((a, b) => {
    const pa = PRIORITY_WEIGHT[a.priority] ?? 1;
    const pb = PRIORITY_WEIGHT[b.priority] ?? 1;
    if (pa !== pb) return pb - pa;
    return (a.estimatedHours ?? 1) - (b.estimatedHours ?? 1);
  });

  const scheduled = [];
  let usedHours = 0;

  for (const task of sorted) {
    const effort = task.estimatedHours ?? 1;
    if (usedHours + effort <= sprintCapacityHours) {
      scheduled.push(task);
      usedHours += effort;
    }
  }

  return {
    scheduled,
    usedHours,
    remainingCapacity: sprintCapacityHours - usedHours,
    utilisation: Math.round((usedHours / sprintCapacityHours) * 100),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. 0/1 KNAPSACK — Optimal sprint planning under effort constraints
//    Real-world use: Unlike greedy (which can miss higher-value combinations),
//    0/1 Knapsack guarantees the maximum-value subset of tasks that fits inside
//    sprint capacity. Each task is either in the sprint (1) or not (0).
//
//    Time  : O(n × W)   n = tasks, W = capacity (hours × 2 for 0.5h granularity)
//    Space : O(n × W)
// ─────────────────────────────────────────────────────────────────────────────
export function knapsackSprint(tasks, sprintCapacityHours) {
  const eligible = tasks.filter((t) => t.status !== "done");

  // Discretise to half-hour slots to keep integer DP feasible
  const SCALE = 2;
  const W = Math.floor(sprintCapacityHours * SCALE);

  const n = eligible.length;
  // dp[i][w] = max value using first i tasks with capacity w (slots)
  const dp = Array.from({ length: n + 1 }, () => new Array(W + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    const task = eligible[i - 1];
    const weight = Math.round((task.estimatedHours ?? 1) * SCALE);
    const value = (PRIORITY_WEIGHT[task.priority] ?? 1) * 10 + (task.storyPoints ?? 1);

    for (let w = 0; w <= W; w++) {
      dp[i][w] = dp[i - 1][w]; // don't take task i
      if (w >= weight) {
        dp[i][w] = Math.max(dp[i][w], dp[i - 1][w - weight] + value);
      }
    }
  }

  // Backtrack to find selected tasks
  const selected = [];
  let w = W;
  for (let i = n; i >= 1; i--) {
    if (dp[i][w] !== dp[i - 1][w]) {
      selected.push(eligible[i - 1]);
      w -= Math.round((eligible[i - 1].estimatedHours ?? 1) * SCALE);
    }
  }

  const totalHours = selected.reduce((s, t) => s + (t.estimatedHours ?? 1), 0);

  return {
    selected: selected.reverse(),
    totalValue: dp[n][W],
    totalHours,
    utilisation: Math.round((totalHours / sprintCapacityHours) * 100),
    dpTableSize: `${n + 1} × ${W + 1}`,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// 7. BRANCH AND BOUND — Optimal task-to-member assignment
//    Real-world use: Given N tasks and M members with different skill scores
//    per task, B&B finds the assignment that maximises total team productivity
//    while respecting each member's max-hours constraint.
//    Pruning avoids exploring provably suboptimal branches.
//
//    Time  : O(M^N) worst case, O(M × N) best case with tight bounds
//    Space : O(N)   recursion depth = number of tasks
// ─────────────────────────────────────────────────────────────────────────────
export function branchAndBoundAssign(tasks, members) {
  if (tasks.length === 0 || members.length === 0) {
    return { assignments: [], totalScore: 0 };
  }

  // Build skill score matrix: score[taskIdx][memberIdx]
  const score = tasks.map((task) =>
    members.map((member) => computeSkillScore(task, member))
  );

  // Compute upper bound: for each remaining task, take the max possible score
  function upperBound(taskIdx, currentScore, memberLoad) {
    let bound = currentScore;
    for (let t = taskIdx; t < tasks.length; t++) {
      let maxForTask = 0;
      for (let m = 0; m < members.length; m++) {
        const effort = tasks[t].estimatedHours ?? 1;
        const cap = (members[m].weeklyCapacityHours ?? 40);
        if (memberLoad[m] + effort <= cap) {
          maxForTask = Math.max(maxForTask, score[t][m]);
        }
      }
      bound += maxForTask;
    }
    return bound;
  }

  let bestScore = -Infinity;
  let bestAssignment = new Array(tasks.length).fill(-1);

  function dfs(taskIdx, currentScore, assignment, memberLoad) {
    if (taskIdx === tasks.length) {
      if (currentScore > bestScore) {
        bestScore = currentScore;
        bestAssignment = [...assignment];
      }
      return;
    }

    // Pruning: if even optimistic upper bound can't beat current best, cut
    if (upperBound(taskIdx, currentScore, memberLoad) <= bestScore) return;

    for (let m = 0; m < members.length; m++) {
      const effort = tasks[taskIdx].estimatedHours ?? 1;
      const cap = members[m].weeklyCapacityHours ?? 40;

      if (memberLoad[m] + effort <= cap) {
        memberLoad[m] += effort;
        assignment[taskIdx] = m;

        dfs(taskIdx + 1, currentScore + score[taskIdx][m], assignment, memberLoad);

        memberLoad[m] -= effort;
        assignment[taskIdx] = -1;
      }
    }

    // Option: leave task unassigned (will appear as "unassigned")
    assignment[taskIdx] = -1;
    dfs(taskIdx + 1, currentScore, assignment, memberLoad);
  }

  const memberLoad = new Array(members.length).fill(0);
  dfs(0, 0, new Array(tasks.length).fill(-1), memberLoad);

  const assignments = bestAssignment.map((memberIdx, taskIdx) => ({
    task: tasks[taskIdx],
    assignedTo: memberIdx >= 0 ? members[memberIdx] : null,
    score: memberIdx >= 0 ? score[taskIdx][memberIdx] : 0,
  }));

  return { assignments, totalScore: bestScore };
}

function computeSkillScore(task, member) {
  let score = 0;
  const skills = member.skills ?? [];

  // Skill tag overlap
  for (const tag of (task.tags ?? [])) {
    if (skills.includes(tag)) score += 10;
  }

  // Past task completion rate bonus
  score += Math.round((member.completionRate ?? 0.5) * 20);

  // Seniority bonus
  const seniorityMap = { junior: 5, mid: 10, senior: 15 };
  score += seniorityMap[member.seniority] ?? 5;

  return score;
}

// ─────────────────────────────────────────────────────────────────────────────
// 8. BOYER-MOORE — Fast task search (bad character heuristic)
//    Real-world use: Teams search task boards with keyword queries. Boyer-Moore
//    searches O(n/m) on average — significantly faster than naive O(nm) scan —
//    which matters when searching across thousands of task titles.
//
//    Time  : O(n/m) average, O(nm) worst case
//    Space : O(σ)   σ = alphabet size (256 ASCII)
// ─────────────────────────────────────────────────────────────────────────────
export function boyerMooreSearch(tasks, query) {
  if (!query || query.trim() === "") return tasks;

  const pattern = query.toLowerCase().trim();
  const m = pattern.length;

  if (m === 0) return tasks;

  // Build bad character table: last occurrence of each character in pattern
  const badChar = new Map();
  for (let i = 0; i < m; i++) {
    badChar.set(pattern[i], i);
  }

  function searchInText(text) {
    const t = text.toLowerCase();
    const n = t.length;
    const occurrences = [];

    let s = 0;  // shift of pattern relative to text
    while (s <= n - m) {
      let j = m - 1;

      // Scan right-to-left
      while (j >= 0 && pattern[j] === t[s + j]) j--;

      if (j < 0) {
        occurrences.push(s);
        s += (s + m < n) ? m - (badChar.get(t[s + m]) ?? -1) : 1;
      } else {
        const bc = badChar.get(t[s + j]) ?? -1;
        s += Math.max(1, j - bc);
      }
    }
    return occurrences.length > 0;
  }

  return tasks.filter((task) => {
    return searchInText(task.title) ||
           (task.description && searchInText(task.description)) ||
           (task.tags ?? []).some((tag) => searchInText(tag));
  });
}
