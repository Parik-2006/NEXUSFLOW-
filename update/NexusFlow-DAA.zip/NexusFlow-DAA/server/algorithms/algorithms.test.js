/**
 * NexusFlow — DAA Algorithm Unit Tests
 * =====================================
 * Run with: node --experimental-vm-modules algorithms.test.js
 * (No test runner needed — pure Node.js assertions)
 *
 * Covers: Merge Sort, Topological Sort, DFS, BFS,
 *         Greedy Scheduling, 0/1 Knapsack, Branch & Bound, Boyer-Moore
 */

import assert from "assert";
import {
  mergeSortTasks,
  topologicalSort,
  dfsBlockedTasks,
  bfsDependencyLevels,
  greedySchedule,
  knapsackSprint,
  branchAndBoundAssign,
  boyerMooreSearch,
} from "./index.js";

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✅ ${name}`);
    passed++;
  } catch (e) {
    console.error(`  ❌ ${name}`);
    console.error(`     ${e.message}`);
    failed++;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared fixtures
// ─────────────────────────────────────────────────────────────────────────────
const makeTask = (overrides) => ({
  _id: overrides.id ?? `t_${Math.random().toString(36).slice(2)}`,
  title: "Task",
  status: "todo",
  priority: "medium",
  estimatedHours: 2,
  storyPoints: 3,
  dependencies: [],
  tags: [],
  createdAt: new Date("2024-01-01").toISOString(),
  dueDate: null,
  ...overrides,
});

// ─────────────────────────────────────────────────────────────────────────────
// 1. MERGE SORT
// ─────────────────────────────────────────────────────────────────────────────
console.log("\n📊 Merge Sort");

test("sorts by priority DESC (high before medium before low)", () => {
  const tasks = [
    makeTask({ id: "a", priority: "low" }),
    makeTask({ id: "b", priority: "high" }),
    makeTask({ id: "c", priority: "medium" }),
  ];
  const sorted = mergeSortTasks(tasks);
  assert.strictEqual(sorted[0]._id, "b", "high should be first");
  assert.strictEqual(sorted[1]._id, "c", "medium should be second");
  assert.strictEqual(sorted[2]._id, "a", "low should be last");
});

test("breaks ties with dueDate ASC (closer deadline first)", () => {
  const tasks = [
    makeTask({ id: "x", priority: "high", dueDate: "2024-03-01" }),
    makeTask({ id: "y", priority: "high", dueDate: "2024-02-01" }),
  ];
  const sorted = mergeSortTasks(tasks);
  assert.strictEqual(sorted[0]._id, "y", "earlier deadline should be first");
});

test("tertiary sort by createdAt ASC (FIFO) when priority and dueDate equal", () => {
  const tasks = [
    makeTask({ id: "p", priority: "medium", createdAt: "2024-01-03T00:00:00.000Z" }),
    makeTask({ id: "q", priority: "medium", createdAt: "2024-01-01T00:00:00.000Z" }),
  ];
  const sorted = mergeSortTasks(tasks);
  assert.strictEqual(sorted[0]._id, "q", "older task should be first (FIFO)");
});

test("returns empty array for empty input", () => {
  assert.deepStrictEqual(mergeSortTasks([]), []);
});

test("single element passes through", () => {
  const t = makeTask({ id: "solo" });
  assert.strictEqual(mergeSortTasks([t])[0]._id, "solo");
});

test("stable: equal-priority tasks preserve relative order", () => {
  const tasks = [
    makeTask({ id: "m1", priority: "medium", createdAt: "2024-01-01T00:00:00.000Z" }),
    makeTask({ id: "m2", priority: "medium", createdAt: "2024-01-02T00:00:00.000Z" }),
    makeTask({ id: "m3", priority: "medium", createdAt: "2024-01-03T00:00:00.000Z" }),
  ];
  const sorted = mergeSortTasks(tasks);
  assert.strictEqual(sorted[0]._id, "m1");
  assert.strictEqual(sorted[1]._id, "m2");
  assert.strictEqual(sorted[2]._id, "m3");
});

// ─────────────────────────────────────────────────────────────────────────────
// 2. TOPOLOGICAL SORT
// ─────────────────────────────────────────────────────────────────────────────
console.log("\n🔀 Topological Sort");

test("linear chain: A→B→C produces [A, B, C] order", () => {
  const a = makeTask({ id: "A", dependencies: [] });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const c = makeTask({ id: "C", dependencies: ["B"] });
  const { ordered, hasCycle } = topologicalSort([a, b, c]);
  assert.strictEqual(hasCycle, false);
  const ids = ordered.map((t) => t._id);
  assert.ok(ids.indexOf("A") < ids.indexOf("B"), "A before B");
  assert.ok(ids.indexOf("B") < ids.indexOf("C"), "B before C");
});

test("diamond DAG (A→B, A→C, B→D, C→D) has no cycle and D is last", () => {
  const a = makeTask({ id: "A", dependencies: [] });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const c = makeTask({ id: "C", dependencies: ["A"] });
  const d = makeTask({ id: "D", dependencies: ["B", "C"] });
  const { ordered, hasCycle } = topologicalSort([a, b, c, d]);
  assert.strictEqual(hasCycle, false);
  assert.strictEqual(ordered[ordered.length - 1]._id, "D");
});

test("detects cycle A→B→C→A and hasCycle = true", () => {
  const a = makeTask({ id: "A", dependencies: ["C"] });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const c = makeTask({ id: "C", dependencies: ["B"] });
  const { hasCycle } = topologicalSort([a, b, c]);
  assert.strictEqual(hasCycle, true);
});

test("independent tasks all appear in result with hasCycle = false", () => {
  const tasks = [makeTask({ id: "X" }), makeTask({ id: "Y" }), makeTask({ id: "Z" })];
  const { ordered, hasCycle } = topologicalSort(tasks);
  assert.strictEqual(hasCycle, false);
  assert.strictEqual(ordered.length, 3);
});

test("levels: linear chain produces 3 single-task levels", () => {
  const a = makeTask({ id: "A" });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const c = makeTask({ id: "C", dependencies: ["B"] });
  const { levels } = topologicalSort([a, b, c]);
  assert.strictEqual(levels.length, 3);
  assert.strictEqual(levels[0][0]._id, "A");
  assert.strictEqual(levels[2][0]._id, "C");
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. DFS — Blocked tasks
// ─────────────────────────────────────────────────────────────────────────────
console.log("\n🌊 DFS Blocked Tasks");

test("B depends on A → blocking A returns [B]", () => {
  const a = makeTask({ id: "A" });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const blocked = dfsBlockedTasks([a, b], "A");
  assert.strictEqual(blocked.length, 1);
  assert.strictEqual(blocked[0]._id, "B");
});

test("chain A→B→C: blocking A returns [B, C]", () => {
  const a = makeTask({ id: "A" });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const c = makeTask({ id: "C", dependencies: ["B"] });
  const blocked = dfsBlockedTasks([a, b, c], "A");
  const ids = blocked.map((t) => t._id);
  assert.ok(ids.includes("B") && ids.includes("C"), "B and C should be blocked");
  assert.strictEqual(blocked.length, 2);
});

test("blocking a leaf task (no dependents) returns []", () => {
  const a = makeTask({ id: "A" });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const blocked = dfsBlockedTasks([a, b], "B");
  assert.strictEqual(blocked.length, 0);
});

test("source task not included in its own blocked set", () => {
  const a = makeTask({ id: "A" });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const blocked = dfsBlockedTasks([a, b], "A");
  assert.ok(!blocked.some((t) => t._id === "A"), "A should not be in blocked list");
});

// ─────────────────────────────────────────────────────────────────────────────
// 4. BFS — Dependency wave plan
// ─────────────────────────────────────────────────────────────────────────────
console.log("\n🌐 BFS Wave Plan");

test("independent tasks all land in wave 0", () => {
  const tasks = [makeTask({ id: "A" }), makeTask({ id: "B" }), makeTask({ id: "C" })];
  const waves = bfsDependencyLevels(tasks);
  assert.strictEqual(waves.length, 1);
  assert.strictEqual(waves[0].length, 3);
});

test("A→B→C produces 3 waves of 1 task each", () => {
  const a = makeTask({ id: "A" });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const c = makeTask({ id: "C", dependencies: ["B"] });
  const waves = bfsDependencyLevels([a, b, c]);
  assert.strictEqual(waves.length, 3);
  assert.strictEqual(waves[0][0]._id, "A");
  assert.strictEqual(waves[2][0]._id, "C");
});

test("diamond DAG (A→B,A→C,B→D,C→D) produces waves: [A],[B,C],[D]", () => {
  const a = makeTask({ id: "A" });
  const b = makeTask({ id: "B", dependencies: ["A"] });
  const c = makeTask({ id: "C", dependencies: ["A"] });
  const d = makeTask({ id: "D", dependencies: ["B", "C"] });
  const waves = bfsDependencyLevels([a, b, c, d]);
  assert.strictEqual(waves.length, 3);
  assert.strictEqual(waves[0].length, 1);  // [A]
  assert.strictEqual(waves[1].length, 2);  // [B, C]
  assert.strictEqual(waves[2].length, 1);  // [D]
});

// ─────────────────────────────────────────────────────────────────────────────
// 5. GREEDY SCHEDULING
// ─────────────────────────────────────────────────────────────────────────────
console.log("\n⚡ Greedy Scheduling");

test("selects all tasks when total effort ≤ capacity", () => {
  const tasks = [
    makeTask({ id: "A", priority: "high", estimatedHours: 2 }),
    makeTask({ id: "B", priority: "medium", estimatedHours: 3 }),
  ];
  const result = greedySchedule(tasks, 10);
  assert.strictEqual(result.scheduled.length, 2);
});

test("respects capacity constraint — stops when full", () => {
  const tasks = [
    makeTask({ id: "A", priority: "high", estimatedHours: 6 }),
    makeTask({ id: "B", priority: "high", estimatedHours: 6 }),
  ];
  const result = greedySchedule(tasks, 8);
  assert.strictEqual(result.scheduled.length, 1);
  assert.ok(result.usedHours <= 8);
});

test("prefers high-priority tasks over low-priority when capacity is limited", () => {
  const tasks = [
    makeTask({ id: "L", priority: "low", estimatedHours: 5 }),
    makeTask({ id: "H", priority: "high", estimatedHours: 5 }),
  ];
  const result = greedySchedule(tasks, 5);
  assert.strictEqual(result.scheduled[0]._id, "H");
});

test("excludes done tasks from scheduling", () => {
  const tasks = [
    makeTask({ id: "D", status: "done", priority: "high", estimatedHours: 1 }),
    makeTask({ id: "T", status: "todo", priority: "medium", estimatedHours: 1 }),
  ];
  const result = greedySchedule(tasks, 10);
  assert.ok(!result.scheduled.some((t) => t._id === "D"), "done task must be excluded");
});

test("utilisation is correctly computed", () => {
  const tasks = [makeTask({ id: "A", priority: "high", estimatedHours: 4 })];
  const result = greedySchedule(tasks, 8);
  assert.strictEqual(result.utilisation, 50);
});

// ─────────────────────────────────────────────────────────────────────────────
// 6. 0/1 KNAPSACK
// ─────────────────────────────────────────────────────────────────────────────
console.log("\n🎒 0/1 Knapsack");

test("empty backlog returns empty selection", () => {
  const result = knapsackSprint([], 40);
  assert.strictEqual(result.selected.length, 0);
});

test("selects optimal subset (not greedy fallthrough)", () => {
  // Greedy picks A(5h,HIGH) leaving 3h → picks C(2h,MED). Value = 30+20 = 50
  // Knapsack can pick B(4h,HIGH)+C(2h,MED) = 6h → value = 30+20 = 50 same
  // OR A(5h)+nothing = 30. Best is B+C.
  // This tests that DP finds max value, not just greedy order.
  const tasks = [
    makeTask({ id: "A", priority: "high", estimatedHours: 5, storyPoints: 1 }),
    makeTask({ id: "B", priority: "high", estimatedHours: 4, storyPoints: 1 }),
    makeTask({ id: "C", priority: "medium", estimatedHours: 2, storyPoints: 1 }),
  ];
  const result = knapsackSprint(tasks, 6);
  // B+C fits in 6h, value same. A alone doesn't fit with C (5+2>6). Verify selected ≤ 6h
  assert.ok(result.totalHours <= 6, `total hours ${result.totalHours} exceeds capacity 6`);
});

test("all done tasks are excluded", () => {
  const tasks = [
    makeTask({ id: "D1", status: "done", priority: "high", estimatedHours: 1 }),
    makeTask({ id: "T1", status: "todo", priority: "medium", estimatedHours: 2 }),
  ];
  const result = knapsackSprint(tasks, 10);
  assert.ok(!result.selected.some((t) => t._id === "D1"), "done tasks excluded");
});

test("never exceeds capacity", () => {
  const tasks = Array.from({ length: 10 }, (_, i) =>
    makeTask({ id: `t${i}`, priority: "high", estimatedHours: 3 })
  );
  const result = knapsackSprint(tasks, 10);
  assert.ok(result.totalHours <= 10, `overflowed: used ${result.totalHours}h`);
});

test("dpTableSize reflects n+1 rows × W+1 cols", () => {
  const tasks = [makeTask({ id: "x", estimatedHours: 2 })];
  const result = knapsackSprint(tasks, 4);
  assert.ok(result.dpTableSize.includes("2 ×"), "should have 2 rows (n+1)");
});

// ─────────────────────────────────────────────────────────────────────────────
// 7. BRANCH AND BOUND
// ─────────────────────────────────────────────────────────────────────────────
console.log("\n🌲 Branch and Bound");

const makeMember = (overrides) => ({
  userId: overrides.id ?? "m1",
  name: overrides.name ?? "Member",
  skills: overrides.skills ?? [],
  seniority: overrides.seniority ?? "mid",
  weeklyCapacityHours: overrides.weeklyCapacityHours ?? 40,
  completionRate: overrides.completionRate ?? 0.8,
  ...overrides,
});

test("returns empty result when no tasks", () => {
  const result = branchAndBoundAssign([], [makeMember({ id: "m1" })]);
  assert.strictEqual(result.assignments.length, 0);
});

test("returns empty result when no members", () => {
  const result = branchAndBoundAssign([makeTask({ id: "t1" })], []);
  assert.strictEqual(result.assignments.length, 0);
});

test("single task → single member → assigns to that member", () => {
  const task = makeTask({ id: "t1", estimatedHours: 4 });
  const member = makeMember({ id: "m1", weeklyCapacityHours: 40 });
  const result = branchAndBoundAssign([task], [member]);
  assert.strictEqual(result.assignments[0].assignedTo?.userId, "m1");
});

test("skill-matching member gets higher score than non-matching member", () => {
  const task = makeTask({ id: "t1", tags: ["react"], estimatedHours: 2 });
  const expert = makeMember({ id: "m_expert", skills: ["react"], weeklyCapacityHours: 40 });
  const novice = makeMember({ id: "m_novice", skills: ["java"], weeklyCapacityHours: 40 });
  const result = branchAndBoundAssign([task], [expert, novice]);
  assert.strictEqual(result.assignments[0].assignedTo?.userId, "m_expert");
});

test("respects weeklyCapacityHours — does not overload member", () => {
  const tasks = [
    makeTask({ id: "t1", estimatedHours: 20 }),
    makeTask({ id: "t2", estimatedHours: 20 }),
    makeTask({ id: "t3", estimatedHours: 20 }),
  ];
  const member = makeMember({ id: "m1", weeklyCapacityHours: 30 });
  const result = branchAndBoundAssign(tasks, [member]);
  const assigned = result.assignments.filter((a) => a.assignedTo?.userId === "m1");
  const totalHours = assigned.reduce((s, a) => s + (a.task.estimatedHours ?? 0), 0);
  assert.ok(totalHours <= 30, `member overloaded: ${totalHours}h > 30h`);
});

// ─────────────────────────────────────────────────────────────────────────────
// 8. BOYER-MOORE SEARCH
// ─────────────────────────────────────────────────────────────────────────────
console.log("\n🔍 Boyer-Moore Search");

const searchTasks = [
  makeTask({ id: "s1", title: "Implement login API", description: "JWT auth endpoint" }),
  makeTask({ id: "s2", title: "Fix payment bug", description: "Stripe webhook failing" }),
  makeTask({ id: "s3", title: "Write unit tests", description: "Coverage for auth module", tags: ["testing"] }),
  makeTask({ id: "s4", title: "Deploy to production", description: "AWS ECS rollout" }),
  makeTask({ id: "s5", title: "Update documentation", description: "API docs for login" }),
];

test("finds tasks matching title substring", () => {
  const results = boyerMooreSearch(searchTasks, "login");
  const ids = results.map((t) => t._id);
  assert.ok(ids.includes("s1"), "s1 title has 'login'");
  assert.ok(ids.includes("s5"), "s5 description has 'login'");
});

test("search is case-insensitive", () => {
  const results = boyerMooreSearch(searchTasks, "DEPLOY");
  assert.ok(results.some((t) => t._id === "s4"), "should match 'Deploy' case-insensitively");
});

test("searches description field", () => {
  const results = boyerMooreSearch(searchTasks, "Stripe");
  assert.strictEqual(results.length, 1);
  assert.strictEqual(results[0]._id, "s2");
});

test("searches tags field", () => {
  const results = boyerMooreSearch(searchTasks, "testing");
  assert.ok(results.some((t) => t._id === "s3"), "tag 'testing' should match");
});

test("empty query returns all tasks", () => {
  const results = boyerMooreSearch(searchTasks, "");
  assert.strictEqual(results.length, searchTasks.length);
});

test("returns empty array when no match", () => {
  const results = boyerMooreSearch(searchTasks, "xyznonexistent");
  assert.strictEqual(results.length, 0);
});

test("single-character pattern works correctly", () => {
  const tasks = [makeTask({ id: "a", title: "Alpha" }), makeTask({ id: "b", title: "Beta" })];
  const results = boyerMooreSearch(tasks, "A");
  assert.ok(results.some((t) => t._id === "a"), "Alpha contains A");
});

test("pattern longer than text does not crash", () => {
  const tasks = [makeTask({ id: "x", title: "Hi" })];
  const results = boyerMooreSearch(tasks, "This is a very long search pattern");
  assert.strictEqual(results.length, 0);
});

// ─────────────────────────────────────────────────────────────────────────────
// Results
// ─────────────────────────────────────────────────────────────────────────────
console.log(`\n${"─".repeat(50)}`);
console.log(`Results: ${passed} passed, ${failed} failed`);
if (failed > 0) {
  console.error("❌ Some tests failed");
  process.exit(1);
} else {
  console.log("✅ All tests passed");
}
