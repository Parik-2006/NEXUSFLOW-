import Task from "../models/Task.js";
import Team from "../models/Team.js";
import { greedySchedule, mergeSortTasks } from "../algorithms/index.js";

/**
 * AI orchestrator — enhanced with DAA pipeline.
 *
 * When @ai creates tasks, they are:
 *  1. Persisted with parsed priority/effort hints from the LLM output
 *  2. Run through Greedy Scheduling to determine sprint feasibility
 *  3. Broadcast in Merge Sort order so boards auto-rank
 *
 * Runs in MOCK mode when OPENAI_API_KEY is unset.
 */
const OPENAI_KEY = process.env.OPENAI_API_KEY;

export function registerAiOrchestrator(io, socket) {
  socket.on("chat:message", async ({ teamId, text }) => {
    const human = {
      _id: `m_${Date.now()}`,
      text,
      userId: socket.data.user?.id ?? "anon",
      name: socket.data.user?.name ?? "Member",
      createdAt: new Date().toISOString(),
    };
    io.to(`team:${teamId}`).emit("chat:message", human);

    if (!/^\s*@ai\b/i.test(text)) return;
    const prompt = text.replace(/^\s*@ai\b/i, "").trim();

    if (OPENAI_KEY) {
      await streamFromOpenAI(io, socket, teamId, prompt);
    } else {
      await streamMock(io, socket, teamId, prompt);
    }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Mock streamer — illustrates the DAA pipeline without a real LLM
// ─────────────────────────────────────────────────────────────────────────────
async function streamMock(io, socket, teamId, prompt) {
  // Structured blocks: title|priority|hours
  const rawBlocks = [
    `Planning: "${prompt}"`,
    "1. Define scope and acceptance criteria|high|2",
    "2. Implement core slice|high|4",
    "3. Add tests and wire CI|medium|3",
    "4. Update documentation|low|1",
  ];

  for (let i = 0; i < rawBlocks.length; i++) {
    await delay(250);
    const displayText = rawBlocks[i].split("|")[0];
    io.to(`team:${teamId}`).emit("chat:stream", {
      id: `ai_${Date.now()}_${i}`,
      text: displayText,
    });
  }

  // Parse and persist task blocks (skip the planning header at index 0)
  const createdTasks = [];
  for (const raw of rawBlocks.slice(1)) {
    const [titleRaw, priority, hoursRaw] = raw.split("|");
    const title = titleRaw.replace(/^[-*\d.\s]+/, "").trim();
    const estimatedHours = parseFloat(hoursRaw) || 1;

    const task = await Task.create({
      teamId,
      title,
      priority: priority ?? "medium",
      estimatedHours,
      createdBy: "ai",
    });
    await Team.updateOne({ _id: teamId }, { $inc: { taskCount: 1 } });
    createdTasks.push(task.toObject());
    io.to(`team:${teamId}`).emit("task:created", task.toObject());
  }

  // Run Greedy Scheduling on the newly created tasks to show sprint feasibility
  const team = await Team.findById(teamId).lean();
  const sprintCapacity = team?.sprintCapacityHours ?? 80;
  const result = greedySchedule(createdTasks, sprintCapacity);

  io.to(`team:${teamId}`).emit("chat:stream", {
    id: `ai_greedy_${Date.now()}`,
    text: `📊 Greedy Sprint Analysis: ${result.scheduled.length}/${createdTasks.length} tasks fit in ${sprintCapacity}h sprint (${result.utilisation}% utilisation, ${result.usedHours}h used)`,
  });

  // Emit merged-sorted full task list so board re-ranks
  const allTasks = await Task.find({ teamId }).lean();
  const sorted = mergeSortTasks(allTasks);
  io.to(`team:${teamId}`).emit("task:reranked", { teamId, tasks: sorted });
}

// ─────────────────────────────────────────────────────────────────────────────
// Real OpenAI streaming — parses structured hints from LLM output
// ─────────────────────────────────────────────────────────────────────────────
async function streamFromOpenAI(io, socket, teamId, prompt) {
  const systemPrompt = `You are a project planning assistant. 
Break the user's request into actionable task titles.
For each task output exactly: TASK|<title>|<priority: low|medium|high>|<estimatedHours: number>
One task per line. Include only lines that start with TASK|.
Also include a brief planning summary on the first line starting with PLAN|.`;

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      stream: true,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt },
      ],
    }),
  });

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let acc = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (payload === "[DONE]") continue;
      try {
        const delta = JSON.parse(payload).choices?.[0]?.delta?.content ?? "";
        if (delta) {
          acc += delta;
          // Stream display-friendly version (strip protocol prefix)
          const displayDelta = delta.replace(/^(TASK|PLAN)\|/, "").replace(/\|[^|]*\|[\d.]+$/, "");
          if (displayDelta.trim()) {
            io.to(`team:${teamId}`).emit("chat:stream", { id: `ai_${Date.now()}`, text: displayDelta });
          }
        }
      } catch { /* ignore keep-alive */ }
    }
  }

  // Parse structured output
  const createdTasks = [];
  for (const line of acc.split("\n")) {
    if (!line.startsWith("TASK|")) continue;
    const parts = line.slice(5).split("|");
    const [title, priority, hoursStr] = parts;
    if (!title?.trim()) continue;

    const estimatedHours = parseFloat(hoursStr) || 1;
    const task = await Task.create({
      teamId,
      title: title.trim(),
      priority: ["low", "medium", "high"].includes(priority) ? priority : "medium",
      estimatedHours,
      createdBy: "ai",
    });
    await Team.updateOne({ _id: teamId }, { $inc: { taskCount: 1 } });
    createdTasks.push(task.toObject());
    io.to(`team:${teamId}`).emit("task:created", task.toObject());
  }

  // Post-creation: Greedy sprint fit analysis
  if (createdTasks.length > 0) {
    const team = await Team.findById(teamId).lean();
    const sprintCapacity = team?.sprintCapacityHours ?? 80;
    const result = greedySchedule(createdTasks, sprintCapacity);

    io.to(`team:${teamId}`).emit("chat:stream", {
      id: `ai_greedy_${Date.now()}`,
      text: `📊 Sprint fit (Greedy): ${result.scheduled.length}/${createdTasks.length} tasks, ${result.usedHours}h / ${sprintCapacity}h (${result.utilisation}% utilised)`,
    });

    const allTasks = await Task.find({ teamId }).lean();
    const sorted = mergeSortTasks(allTasks);
    io.to(`team:${teamId}`).emit("task:reranked", { teamId, tasks: sorted });
  }
}

const delay = (ms) => new Promise((r) => setTimeout(r, ms));
