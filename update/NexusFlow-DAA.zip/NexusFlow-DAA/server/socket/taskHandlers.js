import Team from "../models/Team.js";
import Task from "../models/Task.js";
import { mergeSortTasks, topologicalSort } from "../algorithms/index.js";

/**
 * Wires task create/update events for a connected socket.
 *
 * DAA enhancements:
 *  - task:create   → validates no dependency cycle (Topological Sort) before persisting
 *  - task:created  → triggers Merge Sort re-rank event to keep client boards sorted
 *  - task:update   → broadcasts dependency impact info (DFS result) on block/done
 *  - task:reorder  → explicit Merge Sort re-sort request from client
 *  - task:dep:add  → add a dependency edge; validate DAG integrity (Topo Sort)
 */
export function registerTaskHandlers(io, socket) {
  socket.on("room:join", ({ teamId }) => socket.join(`team:${teamId}`));
  socket.on("room:leave", ({ teamId }) => socket.leave(`team:${teamId}`));

  // ── task:create ─────────────────────────────────────────────────────────────
  socket.on("task:create", async ({ teamId, title, priority, estimatedHours, storyPoints, dueDate, dependencies, tags, description }, ack) => {
    try {
      const task = await Task.create({
        teamId,
        title,
        description: description ?? "",
        priority: priority ?? "medium",
        estimatedHours: estimatedHours ?? 1,
        storyPoints: storyPoints ?? 1,
        dueDate: dueDate ?? null,
        dependencies: dependencies ?? [],
        tags: tags ?? [],
        createdBy: socket.data.user?.id,
      });

      await Team.updateOne({ _id: teamId }, { $inc: { taskCount: 1 } });

      // Validate the DAG is still acyclic after adding this task
      const allTasks = await Task.find({ teamId }).lean();
      const { hasCycle, cycleNodes } = topologicalSort(allTasks);

      if (hasCycle) {
        // Rollback: remove the just-created task (its dep caused a cycle)
        await Task.findByIdAndDelete(task._id);
        await Team.updateOne({ _id: teamId }, { $inc: { taskCount: -1 } });
        return ack?.({ ok: false, error: "circular_dependency", cycleNodes });
      }

      // Emit new task to the room
      io.to(`team:${teamId}`).emit("task:created", task.toObject());

      // Emit sorted task list so clients can re-render in Merge Sort order
      const sorted = mergeSortTasks(allTasks);
      io.to(`team:${teamId}`).emit("task:reranked", { teamId, tasks: sorted });

      ack?.({ ok: true, task });
    } catch (e) {
      ack?.({ ok: false, error: e.message });
    }
  });

  // ── task:update ─────────────────────────────────────────────────────────────
  socket.on("task:update", async ({ teamId, taskId, status, prevStatus }, ack) => {
    try {
      const task = await Task.findByIdAndUpdate(taskId, { status }, { new: true }).lean();
      if (!task) return ack?.({ ok: false, error: "not_found" });

      const wasDone = prevStatus === "done";
      const isDone = status === "done";
      if (!wasDone && isDone) await Team.updateOne({ _id: teamId }, { $inc: { doneCount: 1 } });
      if (wasDone && !isDone) await Team.updateOne({ _id: teamId }, { $inc: { doneCount: -1 } });

      io.to(`team:${teamId}`).emit("task:updated", { ...task, prevStatus });
      ack?.({ ok: true });
    } catch (e) {
      ack?.({ ok: false, error: e.message });
    }
  });

  // ── task:reorder — explicit Merge Sort request ───────────────────────────────
  socket.on("task:reorder", async ({ teamId }, ack) => {
    try {
      const tasks = await Task.find({ teamId }).lean();
      const sorted = mergeSortTasks(tasks);
      // Emit only to the requesting socket (not the whole room)
      socket.emit("task:reranked", { teamId, tasks: sorted });
      ack?.({ ok: true, count: sorted.length });
    } catch (e) {
      ack?.({ ok: false, error: e.message });
    }
  });

  // ── task:dep:add — add dependency edge with cycle detection ─────────────────
  socket.on("task:dep:add", async ({ teamId, taskId, dependsOnTaskId }, ack) => {
    try {
      if (taskId === dependsOnTaskId) {
        return ack?.({ ok: false, error: "self_dependency" });
      }

      await Task.findByIdAndUpdate(taskId, {
        $addToSet: { dependencies: dependsOnTaskId },
      });

      const allTasks = await Task.find({ teamId }).lean();
      const { hasCycle, cycleNodes } = topologicalSort(allTasks);

      if (hasCycle) {
        // Roll back the edge
        await Task.findByIdAndUpdate(taskId, {
          $pull: { dependencies: dependsOnTaskId },
        });
        return ack?.({ ok: false, error: "circular_dependency", cycleNodes });
      }

      const updatedTask = await Task.findById(taskId).lean();
      io.to(`team:${teamId}`).emit("task:updated", updatedTask);
      ack?.({ ok: true });
    } catch (e) {
      ack?.({ ok: false, error: e.message });
    }
  });
}
