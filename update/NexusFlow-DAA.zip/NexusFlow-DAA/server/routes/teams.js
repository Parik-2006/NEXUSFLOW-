import { Router } from "express";
import Team from "../models/Team.js";
import Task from "../models/Task.js";
import { requireAuth } from "../auth.js";
import {
  mergeSortTasks,
  topologicalSort,
  bfsDependencyLevels,
  dfsBlockedTasks,
  greedySchedule,
  knapsackSprint,
  branchAndBoundAssign,
  boyerMooreSearch,
} from "../algorithms/index.js";

const router = Router();

// ─────────────────────────────────────────────────────────────────────────────
// Existing endpoints — preserved, backward compatible
// ─────────────────────────────────────────────────────────────────────────────

// Hydrate: list teams with progress counts.
router.get("/teams", requireAuth, async (_req, res) => {
  try {
    const teams = await Team.find().lean();
    res.json(teams);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Hydrate: raw tasks for a team (snapshot before socket subscribe).
// Now sorted by Merge Sort instead of MongoDB's insertion order.
router.get("/teams/:teamId/tasks", requireAuth, async (req, res) => {
  try {
    const tasks = await Task.find({ teamId: req.params.teamId }).lean();
    // Merge Sort: O(n log n) — sort by priority DESC, dueDate ASC, createdAt ASC
    const sorted = mergeSortTasks(tasks);
    res.json(sorted);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DAA ENDPOINT 1: Topological Sort — execution ordering
// GET /api/teams/:teamId/tasks/execution-order
// Returns tasks in valid execution order respecting all dependencies.
// ─────────────────────────────────────────────────────────────────────────────
router.get("/teams/:teamId/tasks/execution-order", requireAuth, async (req, res) => {
  try {
    const tasks = await Task.find({ teamId: req.params.teamId }).lean();
    const result = topologicalSort(tasks);

    if (result.hasCycle) {
      return res.status(422).json({
        error: "circular_dependency",
        message: "Dependency cycle detected. Cannot determine execution order.",
        cycleNodes: result.cycleNodes,
      });
    }

    res.json({
      algorithm: "Topological Sort (Kahn's BFS)",
      complexity: { time: "O(V + E)", space: "O(V + E)" },
      ordered: result.ordered,
      levels: result.levels,  // sprint wave plan
      totalTasks: result.ordered.length,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DAA ENDPOINT 2: BFS — dependency wave plan (sprint calendar)
// GET /api/teams/:teamId/tasks/wave-plan
// Returns tasks grouped by parallel execution waves.
// ─────────────────────────────────────────────────────────────────────────────
router.get("/teams/:teamId/tasks/wave-plan", requireAuth, async (req, res) => {
  try {
    const tasks = await Task.find({ teamId: req.params.teamId }).lean();
    const waves = bfsDependencyLevels(tasks);

    res.json({
      algorithm: "BFS Dependency Level Exploration",
      complexity: { time: "O(V + E)", space: "O(V)" },
      waves: waves.map((wave, idx) => ({
        sprint: idx,
        tasks: wave,
        parallelCount: wave.length,
        totalHours: wave.reduce((s, t) => s + (t.estimatedHours ?? 1), 0),
      })),
      totalSprints: waves.length,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DAA ENDPOINT 3: DFS — find all tasks blocked by a given task
// GET /api/teams/:teamId/tasks/:taskId/blocked
// ─────────────────────────────────────────────────────────────────────────────
router.get("/teams/:teamId/tasks/:taskId/blocked", requireAuth, async (req, res) => {
  try {
    const tasks = await Task.find({ teamId: req.params.teamId }).lean();
    const blocked = dfsBlockedTasks(tasks, req.params.taskId);

    res.json({
      algorithm: "DFS Downstream Traversal",
      complexity: { time: "O(V + E)", space: "O(V)" },
      sourceTaskId: req.params.taskId,
      blockedTasks: blocked,
      blockedCount: blocked.length,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DAA ENDPOINT 4: Greedy Scheduling — task prioritisation
// POST /api/teams/:teamId/sprint/greedy
// Body: { capacityHours: number }
// ─────────────────────────────────────────────────────────────────────────────
router.post("/teams/:teamId/sprint/greedy", requireAuth, async (req, res) => {
  try {
    const { capacityHours } = req.body;
    if (!capacityHours || capacityHours <= 0) {
      return res.status(400).json({ error: "capacityHours must be a positive number" });
    }

    const tasks = await Task.find({ teamId: req.params.teamId, status: { $ne: "done" } }).lean();
    const result = greedySchedule(tasks, capacityHours);

    res.json({
      algorithm: "Greedy Activity Selection",
      complexity: { time: "O(n log n)", space: "O(n)" },
      ...result,
      note: "Greedy guarantees near-optimal but not globally optimal. Use Knapsack for guaranteed optimum.",
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DAA ENDPOINT 5: 0/1 Knapsack — optimal sprint planning
// POST /api/teams/:teamId/sprint/knapsack
// Body: { capacityHours: number }
// ─────────────────────────────────────────────────────────────────────────────
router.post("/teams/:teamId/sprint/knapsack", requireAuth, async (req, res) => {
  try {
    const { capacityHours } = req.body;
    if (!capacityHours || capacityHours <= 0) {
      return res.status(400).json({ error: "capacityHours must be a positive number" });
    }

    const tasks = await Task.find({ teamId: req.params.teamId, status: { $ne: "done" } }).lean();

    if (tasks.length > 100) {
      // Guard against O(n*W) blowing up for huge backlogs — fallback to greedy
      const result = greedySchedule(tasks, capacityHours);
      return res.json({ ...result, algorithm: "Greedy (fallback: backlog > 100 tasks)", fallback: true });
    }

    const result = knapsackSprint(tasks, capacityHours);

    res.json({
      algorithm: "0/1 Knapsack DP",
      complexity: { time: "O(n × W)", space: "O(n × W)", note: `DP table: ${result.dpTableSize}` },
      ...result,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DAA ENDPOINT 6: Branch and Bound — optimal task-member assignment
// POST /api/teams/:teamId/assign
// Body: { taskIds?: string[] }  — omit to assign all unassigned tasks
// ─────────────────────────────────────────────────────────────────────────────
router.post("/teams/:teamId/assign", requireAuth, async (req, res) => {
  try {
    const team = await Team.findById(req.params.teamId).lean();
    if (!team) return res.status(404).json({ error: "team not found" });

    const members = team.memberProfiles ?? [];
    if (members.length === 0) {
      return res.status(422).json({ error: "No member profiles found. Add memberProfiles to the team first." });
    }

    const taskFilter = { teamId: req.params.teamId, status: { $ne: "done" }, assignedTo: null };
    if (req.body.taskIds?.length) {
      taskFilter._id = { $in: req.body.taskIds };
    }

    const tasks = await Task.find(taskFilter).lean();
    if (tasks.length === 0) return res.json({ assignments: [], totalScore: 0, message: "No unassigned tasks found." });

    // B&B guards: limit to 10 tasks per call to keep branching tractable
    const tasksToAssign = tasks.slice(0, 10);
    const result = branchAndBoundAssign(tasksToAssign, members);

    // Persist the assignments
    const bulkOps = result.assignments
      .filter((a) => a.assignedTo !== null)
      .map((a) => ({
        updateOne: {
          filter: { _id: a.task._id },
          update: { $set: { assignedTo: a.assignedTo.userId } },
        },
      }));

    if (bulkOps.length > 0) await Task.bulkWrite(bulkOps);

    res.json({
      algorithm: "Branch and Bound",
      complexity: {
        time: "O(M^N) worst, O(M×N) typical with pruning",
        space: "O(N) recursion stack",
      },
      ...result,
      persisted: bulkOps.length,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DAA ENDPOINT 7: Boyer-Moore — fast task search
// GET /api/teams/:teamId/tasks/search?q=<query>
// ─────────────────────────────────────────────────────────────────────────────
router.get("/teams/:teamId/tasks/search", requireAuth, async (req, res) => {
  try {
    const q = req.query.q ?? "";
    const tasks = await Task.find({ teamId: req.params.teamId }).lean();

    const results = boyerMooreSearch(tasks, q);
    // Re-sort results by priority using Merge Sort
    const sorted = mergeSortTasks(results);

    res.json({
      algorithm: "Boyer-Moore (Bad Character Heuristic)",
      complexity: { time: "O(n/m) average", space: "O(σ) = O(256 ASCII)" },
      query: q,
      results: sorted,
      totalMatches: sorted.length,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// Team management helpers (new, backward-compatible)
// ─────────────────────────────────────────────────────────────────────────────

// Create team
router.post("/teams", requireAuth, async (req, res) => {
  try {
    const { name, sprintCapacityHours } = req.body;
    if (!name) return res.status(400).json({ error: "name required" });
    const team = await Team.create({ name, sprintCapacityHours: sprintCapacityHours ?? 80 });
    res.status(201).json(team);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Upsert member profile (skill/capacity for B&B)
router.put("/teams/:teamId/members/:userId/profile", requireAuth, async (req, res) => {
  try {
    const { skills, seniority, weeklyCapacityHours, completionRate, name } = req.body;
    await Team.updateOne(
      { _id: req.params.teamId, "memberProfiles.userId": { $ne: req.params.userId } },
      {
        $push: {
          memberProfiles: {
            userId: req.params.userId,
            name: name ?? req.params.userId,
            skills: skills ?? [],
            seniority: seniority ?? "mid",
            weeklyCapacityHours: weeklyCapacityHours ?? 40,
            completionRate: completionRate ?? 0.8,
          },
        },
      }
    );
    // Update if already exists
    await Team.updateOne(
      { _id: req.params.teamId, "memberProfiles.userId": req.params.userId },
      {
        $set: {
          "memberProfiles.$.skills": skills ?? [],
          "memberProfiles.$.seniority": seniority ?? "mid",
          "memberProfiles.$.weeklyCapacityHours": weeklyCapacityHours ?? 40,
          "memberProfiles.$.completionRate": completionRate ?? 0.8,
          "memberProfiles.$.name": name ?? req.params.userId,
        },
      }
    );
    const team = await Team.findById(req.params.teamId).lean();
    res.json(team);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
