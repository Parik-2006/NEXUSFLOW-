import "dotenv/config";
import express from "express";
import cors from "cors";
import { createServer } from "http";
import { Server } from "socket.io";
import mongoose from "mongoose";
import { verify } from "./auth.js";
import teamRouter from "./routes/teams.js";
import { registerTaskHandlers } from "./socket/taskHandlers.js";
import { registerAiOrchestrator } from "./socket/aiOrchestrator.js";

const app = express();
const httpServer = createServer(app);

const io = new Server(httpServer, {
  cors: { origin: "*" },
});

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// ── Health ────────────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => res.json({ ok: true, service: "nexusflow-daa" }));

// ── Auth routes ───────────────────────────────────────────────────────────────
import User from "./models/User.js";
import { sign, requireAuth } from "./auth.js";

app.post("/api/register", async (req, res) => {
  try {
    const { email, password, name } = req.body;
    if (!email || !password || !name)
      return res.status(400).json({ error: "email, password and name required" });
    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ error: "email already registered" });
    const user = await User.create({ email, password, name });
    const token = sign({ id: user._id.toString(), email: user.email, name: user.name });
    res.status(201).json({ token, user: { id: user._id, email: user.email, name: user.name } });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password)))
      return res.status(401).json({ error: "invalid credentials" });
    const token = sign({ id: user._id.toString(), email: user.email, name: user.name });
    res.json({ token, user: { id: user._id, email: user.email, name: user.name } });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/me", requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password").lean();
    if (!user) return res.status(404).json({ error: "not found" });
    res.json({ id: user._id, email: user.email, name: user.name });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── Team + DAA routes ─────────────────────────────────────────────────────────
// All 9 REST endpoints (including 7 DAA endpoints) live in teamRouter.
app.use("/api", teamRouter);

// ── Socket.io — JWT auth middleware ───────────────────────────────────────────
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  const payload = token ? verify(token) : null;
  if (!payload) return next(new Error("unauthorized"));
  socket.data.user = payload;
  next();
});

io.on("connection", (socket) => {
  registerTaskHandlers(io, socket);   // task CRUD + DAG validation
  registerAiOrchestrator(io, socket); // @ai commands + Greedy post-create
});

// ── MongoDB + server start ────────────────────────────────────────────────────
const MONGO_URI = process.env.MONGO_URI ?? "mongodb://127.0.0.1:27017/nexusflow";
const PORT = Number(process.env.PORT ?? 4000);

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log(`✅ MongoDB connected: ${MONGO_URI}`);
    httpServer.listen(PORT, () =>
      console.log(`🚀 NexusFlow DAA server listening on :${PORT}`)
    );
  })
  .catch((e) => {
    console.error("❌ MongoDB connection error:", e.message);
    process.exit(1);
  });
