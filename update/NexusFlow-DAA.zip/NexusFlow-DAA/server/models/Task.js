import mongoose from "mongoose";

/**
 * Task — enhanced schema for DAA-powered scheduling and optimization.
 *
 * New fields added (all optional, backward-compatible):
 *  priority        — drives Greedy scheduling and Knapsack value function
 *  estimatedHours  — weight in Knapsack and Branch-and-Bound capacity checks
 *  storyPoints     — secondary value signal for Knapsack
 *  dueDate         — secondary sort key in Merge Sort
 *  dependencies    — directed edges in the dependency DAG (Topo/DFS/BFS)
 *  tags            — skill matching in Branch-and-Bound assignment
 *  description     — searched by Boyer-Moore alongside title
 *  assignedTo      — populated by Branch-and-Bound optimal assignment
 */
const TaskSchema = new mongoose.Schema(
  {
    teamId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Team",
      required: true,
      index: true,
    },
    title: { type: String, required: true },
    description: { type: String, default: "" },

    status: {
      type: String,
      enum: ["todo", "in_progress", "done"],
      default: "todo",
    },

    // ── DAA: Greedy + Knapsack fields ────────────────────────────────────────
    priority: {
      type: String,
      enum: ["low", "medium", "high"],
      default: "medium",
    },
    estimatedHours: {
      type: Number,
      default: 1,
      min: 0.5,
    },
    storyPoints: {
      type: Number,
      default: 1,
      min: 1,
    },
    dueDate: { type: Date, default: null },

    // ── DAA: Topological Sort / DFS / BFS dependency edges ───────────────────
    dependencies: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Task",
      },
    ],

    // ── DAA: Branch-and-Bound assignment + Boyer-Moore search ────────────────
    tags: [{ type: String }],
    assignedTo: { type: String, default: null },  // userId or null

    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

// Compound index: teamId + priority for efficient sprint planning queries
TaskSchema.index({ teamId: 1, priority: -1 });
// Text index on title + description for full-text fallback search
TaskSchema.index({ title: "text", description: "text" });

export default mongoose.model("Task", TaskSchema);
