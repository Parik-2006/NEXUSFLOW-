import mongoose from "mongoose";

/**
 * Team — enhanced schema for Branch-and-Bound optimal assignment.
 *
 * New nested memberProfiles array stores skill/capacity metadata so the
 * B&B assignment algorithm can score task-member pairings.
 * Existing top-level members array is preserved for backward compatibility.
 */
const MemberProfileSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true },
    name: { type: String, default: "Member" },
    skills: [{ type: String }],                          // e.g. ["react", "node", "testing"]
    seniority: {
      type: String,
      enum: ["junior", "mid", "senior"],
      default: "mid",
    },
    weeklyCapacityHours: { type: Number, default: 40 },  // B&B capacity constraint
    completionRate: { type: Number, default: 0.8, min: 0, max: 1 }, // historical metric
  },
  { _id: false }
);

const TeamSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },

    // Preserved: array of User ObjectIds (original, backward-compatible)
    members: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],

    // DAA: enriched member profiles for Branch-and-Bound
    memberProfiles: [MemberProfileSchema],

    // Sprint planning metadata
    sprintCapacityHours: { type: Number, default: 80 },  // team total hours per sprint

    taskCount: { type: Number, default: 0 },
    doneCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export default mongoose.model("Team", TeamSchema);
